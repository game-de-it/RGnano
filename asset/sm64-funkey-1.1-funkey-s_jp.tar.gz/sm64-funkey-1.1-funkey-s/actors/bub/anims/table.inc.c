// 0x06012354
const struct Animation *const bub_seg6_anims_06012354[] = {
    &bub_seg6_anim_0601233C,
    NULL,
    NULL,
};
