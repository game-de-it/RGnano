// 0x030156A8
static const struct Animation door_seg3_anim_030156A8 = {
    1,
    0,
    40,
    40,
    0x50,
    ANIMINDEX_NUMPARTS(door_seg3_animindex_03015654),
    door_seg3_animvalue_03015470,
    door_seg3_animindex_03015654,
    0,
};
