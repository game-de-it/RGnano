// 0x0D000450
const GeoLayout treasure_chest_base_geo[] = {
   GEO_NODE_START(),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, treasure_chest_seg6_dl_06016F90),
   GEO_CLOSE_NODE(),
   GEO_END(),
};

// 0x0D000468
const GeoLayout treasure_chest_lid_geo[] = {
   GEO_NODE_START(),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, treasure_chest_seg6_dl_060178C0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
