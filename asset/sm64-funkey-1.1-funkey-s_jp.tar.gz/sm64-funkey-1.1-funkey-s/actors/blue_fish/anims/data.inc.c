#include "anim_0301C298.inc.c"
