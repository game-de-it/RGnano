// 0x0600FB58
const struct Animation *const toad_seg6_anims_0600FB58[] = {
    &toad_seg6_anim_0600B66C,
    &toad_seg6_anim_0600CE78,
    &toad_seg6_anim_0600E414,
    &toad_seg6_anim_0600FB40,
    &toad_seg6_anim_060099F0,
    &toad_seg6_anim_0600A0D0,
    &toad_seg6_anim_06008F7C,
    &toad_seg6_anim_06009310,
};
