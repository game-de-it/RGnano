// 0x050065D8
static const struct Animation monty_mole_seg5_anim_050065D8 = {
    0,
    0,
    0,
    0,
    0x01,
    ANIMINDEX_NUMPARTS(monty_mole_seg5_animindex_0500650C),
    monty_mole_seg5_animvalue_050062C8,
    monty_mole_seg5_animindex_0500650C,
    0,
};
