// 0x06013F7C
const struct Animation *const water_ring_seg6_anims_06013F7C[] = {
    &water_ring_seg6_anim_06013F64,
    NULL,
    NULL,
};
