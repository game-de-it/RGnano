#include "anim_06013F64.inc.c"
