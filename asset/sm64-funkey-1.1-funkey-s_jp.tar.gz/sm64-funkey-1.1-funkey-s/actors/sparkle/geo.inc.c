// 0x170001BC
const GeoLayout sparkles_geo[] = {
   GEO_SWITCH_CASE(12, geo_switch_anim_state),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A570),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A570),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A558),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A558),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A540),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A540),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A528),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A528),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A510),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A510),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A4F8),
      GEO_DISPLAY_LIST(LAYER_ALPHA, sparkles_seg4_dl_0402A4F8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
