// 0x06001028
const struct Animation *const koopa_flag_seg6_anims_06001028[] = {
    &koopa_flag_seg6_anim_06001010,
    NULL,
};
