// unreferenced
// 0x0500616C
const struct Animation *const blargg_seg5_anims_0500616C[] = {
    &blargg_seg5_anim_05006154,
    &blargg_seg5_anim_05006070,
    NULL,
};
