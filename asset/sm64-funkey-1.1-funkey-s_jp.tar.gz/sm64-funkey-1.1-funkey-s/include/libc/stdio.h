#ifndef STDIO_H
#define STDIO_H

extern int sprintf(char *s, const char *fmt, ...);

#endif
